function ejemplo(elemento) {
    console.log("elemento clickeado", elemento);
    elemento.style.backgroundColor = 'blue'; // Cambia el color de fondo del botón
    elemento.textContent = 'El Primo is here 🗣️🔥'; // Cambia el texto del botón
}